# Study Desk — deploy guide (© 2026 LPA)

## Files
- index.html — the whole app
- functions/api/ai.js — secure AI endpoint (keeps your API key off the page)
- privacy.html, terms.html — templates: fill in the [BRACKETS], have a lawyer review
- manifest.webmanifest, icon.svg — lets people "Add to Home Screen" (works like an app on iPhone, iPad, Android, desktop)
- _headers — security headers

## Launch on Cloudflare Pages (free tier is enough to start)
1. Create a free account at cloudflare.com and a free API key at console.anthropic.com (add a small credit balance and set a monthly spend limit there).
2. Put this folder in a GitHub repo (or use "Direct Upload" in Cloudflare Pages and upload the folder).
3. Pages > Create project > connect the repo. Build command: none. Output directory: /
4. Settings > Variables and Secrets > add ANTHROPIC_API_KEY as a Secret. Optional: DAILY_LIMIT (default 60 AI calls per visitor per day), MODEL_DEFAULT, MODEL_COMPLEX.
5. Optional but recommended: create a KV namespace, bind it to the project as RATE so the daily limit is reliable.
6. Redeploy, open your site, try Buddy on the example file.
7. Add your domain under Custom domains.

## Before you tell the public
- Fill in privacy.html and terms.html [BRACKETS] and get a lawyer to review them. No template can promise you will never be sued.
- Set a spend limit in the Anthropic console so a spike cannot cost you more than you choose.
- Check the licences of the libraries used: pdf.js (Apache-2.0), mammoth (BSD-2). Keep their notices if you self-host them.
- Fonts come from Google Fonts. Under some privacy laws (e.g. GDPR) you may prefer to self-host them.
- Real app stores (Apple App Store / Google Play) are separate: they require developer accounts, a native wrapper (e.g. Capacitor), their own review, and a privacy policy. Launch the website first.
