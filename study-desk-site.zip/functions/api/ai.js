// Study Desk (c) 2026 LPA. All rights reserved.
// Cloudflare Pages Function: POST /api/ai  ->  Anthropic Messages API.
// Secrets/config (Pages > Settings > Variables and Secrets):
//   ANTHROPIC_API_KEY (secret, required)
//   MODEL_DEFAULT, MODEL_COMPLEX (optional, default below)
//   DAILY_LIMIT (optional, calls per visitor per day, default 60)
//   RATE (optional KV namespace binding, makes the daily limit reliable)
//   ALLOWED_ORIGIN (optional, e.g. https://yourdomain.com; default same host)
const MAX_BODY = 12 * 1024 * 1024, MAX_PROMPT = 250000, MAX_IMAGES = 4, MAX_IMG_B64 = 6 * 1024 * 1024;
const TYPES = new Set(['image/jpeg', 'image/png', 'image/webp', 'image/gif']);
const mem = new Map();
const json = (o, status = 200, h = {}) => new Response(JSON.stringify(o), { status, headers: { 'content-type': 'application/json', 'cache-control': 'no-store', ...h } });

export async function onRequestPost({ request, env }) {
  if (!env.ANTHROPIC_API_KEY) return json({ error: 'disabled' }, 503);
  const host = new URL(request.url).host, origin = request.headers.get('origin');
  if (origin) { let ok = false; try { ok = new URL(origin).host === host || (env.ALLOWED_ORIGIN && origin === env.ALLOWED_ORIGIN) } catch {} if (!ok) return json({ error: 'forbidden' }, 403) }
  const len = +request.headers.get('content-length') || 0;
  if (len > MAX_BODY) return json({ error: 'too_large' }, 413);
  let b; try { const raw = await request.text(); if (raw.length > MAX_BODY) return json({ error: 'too_large' }, 413); b = JSON.parse(raw) } catch { return json({ error: 'bad_request' }, 400) }
  const prompt = b && b.prompt;
  if (typeof prompt !== 'string' || !prompt.trim() || prompt.length > MAX_PROMPT) return json({ error: 'bad_request' }, 400);
  const images = Array.isArray(b.images) ? b.images : [];
  if (images.length > MAX_IMAGES) return json({ error: 'bad_request' }, 400);
  for (const i of images) if (!i || !TYPES.has(i.type) || typeof i.data !== 'string' || i.data.length > MAX_IMG_B64 || !/^[A-Za-z0-9+/=]+$/.test(i.data)) return json({ error: 'bad_request' }, 400);
  // rate limit per visitor per day (+ burst limit per minute)
  const ip = request.headers.get('cf-connecting-ip') || 'unknown', day = new Date().toISOString().slice(0, 10), limit = +env.DAILY_LIMIT || 60;
  const now = Date.now(), burst = (mem.get('b' + ip) || []).filter(t => now - t < 60000);
  if (burst.length >= 20) return json({ error: 'rate_limited' }, 429);
  burst.push(now); mem.set('b' + ip, burst); if (mem.size > 5000) mem.clear();
  if (env.RATE) { const k = 'd:' + day + ':' + ip, n = +(await env.RATE.get(k)) || 0; if (n >= limit) return json({ error: 'rate_limited' }, 429); await env.RATE.put(k, String(n + 1), { expirationTtl: 172800 }) }
  else { const k = 'd:' + day + ':' + ip, n = mem.get(k) || 0; if (n >= limit) return json({ error: 'rate_limited' }, 429); mem.set(k, n + 1) }
  const complex = b.tier === 'complex';
  const model = complex ? (env.MODEL_COMPLEX || 'claude-opus-5-5') : (env.MODEL_DEFAULT || 'claude-sonnet-5-5');
  const content = [...images.map(i => ({ type: 'image', source: { type: 'base64', media_type: i.type, data: i.data } })), { type: 'text', text: prompt }];
  let r;
  try { r = await fetch('https://api.anthropic.com/v1/messages', { method: 'POST', headers: { 'content-type': 'application/json', 'x-api-key': env.ANTHROPIC_API_KEY, 'anthropic-version': '2023-06-01' }, body: JSON.stringify({ model, max_tokens: complex ? 8192 : 4096, messages: [{ role: 'user', content }] }) }) }
  catch { return json({ error: 'upstream' }, 502) }
  if (r.status === 429 || r.status === 529) return json({ error: 'rate_limited' }, 429);
  if (!r.ok) return json({ error: 'upstream' }, 502);
  const j = await r.json().catch(() => null);
  const text = j && Array.isArray(j.content) ? j.content.filter(c => c.type === 'text').map(c => c.text).join('') : '';
  if (!text) return json({ error: 'upstream' }, 502);
  return json({ text });
}
export const onRequest = () => json({ error: 'method_not_allowed' }, 405, { allow: 'POST' });
